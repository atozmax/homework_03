HW3_C Credentials for parastoo_bahmani
================================

KUBECONFIG:  $(pwd)/kubeconfig.yaml
NAMESPACE:   qbc12-hw03-c-parastoo_bahmani
NODEPORT:    30119
REGISTRY:    185.50.38.163:35000
SERVICE_URL: http://185.50.38.163:30119

Steps:
1. export KUBECONFIG=$(pwd)/kubeconfig.yaml
2. kubectl get nodes
3. docker pull 185.50.38.163:35000/qbc12-hw03-base:v1
4. docker build -t 185.50.38.163:35000/qbc12-embedder-parastoo_bahmani:v1 .
5. docker push 185.50.38.163:35000/qbc12-embedder-parastoo_bahmani:v1
6. kubectl apply -f k8s/
7. curl http://185.50.38.163:30119/healthz/ready
